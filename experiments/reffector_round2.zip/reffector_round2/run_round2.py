#!/usr/bin/env python3
"""Run one independent, externally time-capped Pi benchmark session.

Requires Python 3.10+ and Pi. Never edits source repositories intentionally.
The runner controls the Pi process and records its output/metadata.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

CASES = {
    'caddy-control': ('caddy', '02-caddy-control.md'),
    'caddy-reffector': ('caddy', '03-caddy-reffector.md'),
    'restic-control': ('restic', '04-restic-control.md'),
    'restic-reffector': ('restic', '05-restic-reffector.md'),
}
EXPECTED = {
    'caddy': '0e392c89baa50f558bc24440482c5d57fff4499f',
    'restic': 'dd09b6bd01af220b1d5d95c0d4d7d472e05e05c4',
}
BASE = Path('/Users/rob/Development/reffector-round2')
EXPERIMENTS = Path('/Users/rob/Development/reffector/experiments')


def command(*args: str, cwd: Path | None = None) -> str:
    result = subprocess.run(list(args), cwd=cwd, text=True,
                            capture_output=True, timeout=30, check=True)
    return result.stdout.strip()


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--case', choices=sorted(CASES), required=True)
    ap.add_argument('--run-id', required=True,
                    help='Unique ID, e.g. caddy-control-01 (no existing directory)')
    ap.add_argument('--model', default='openai-codex/gpt-6.1-sol')
    ap.add_argument('--thinking', default='high')
    ap.add_argument('--seconds', type=int, default=300)
    ap.add_argument('--base', type=Path, default=BASE,
                    help='Validated audit/bin plus runs directory')
    ap.add_argument('--experiments', type=Path, default=EXPERIMENTS)
    ap.add_argument('--extension', action='append', default=[],
                    help='Explicitly include only a required model-router extension; SAME for every run')
    a = ap.parse_args()
    if a.seconds != 300:
        ap.error('round-two comparison fixes the same 300-second budget for all four configurations')
    if not a.run_id.startswith(a.case + '-') or '/' in a.run_id or '\\' in a.run_id or '..' in a.run_id:
        ap.error('run-id must start with case plus hyphen and contain no paths')

    basedir = a.base.expanduser().resolve()
    experimentdir = a.experiments.expanduser().resolve()
    repo, prompt_filename = CASES[a.case]
    repo_dir = experimentdir / repo
    prompt_path = Path(__file__).resolve().parent / prompt_filename
    binary = basedir / 'bin' / 'reffector'
    manifest_path = basedir / 'audit' / 'readiness.json'
    if not manifest_path.exists():
        ap.error('missing acceptance audit readiness.json')
    readiness = json.loads(manifest_path.read_text())
    if readiness.get('ready') is not True:
        ap.error('acceptance audit does not say ready=true')
    if readiness.get('caddy_head') != EXPECTED['caddy'] or readiness.get('restic_head') != EXPECTED['restic']:
        ap.error('audit was conducted against different pinned revisions')
    if readiness.get('caddy_scope') != './modules/caddyhttp/...' or readiness.get('restic_scopes') != [
        './internal/repository/...', './internal/backend/local/...'
    ]:
        ap.error('audited scope differs from locked benchmark scope')
    if not prompt_path.exists():
        ap.error(f'missing prompt file {prompt_path}')
    if not repo_dir.is_dir():
        ap.error(f'missing repository {repo_dir}')
    if command('git', 'rev-parse', 'HEAD', cwd=repo_dir) != EXPECTED[repo]:
        ap.error('wrong repository revision')
    status_before = command('git', 'status', '--porcelain=v1', cwd=repo_dir)
    if status_before:
        ap.error('third-party worktree dirty; preserve it and do not benchmark')
    if 'reffector' in a.case:
        if not binary.is_file() or not os.access(binary, os.X_OK):
            ap.error('validated binary missing')
        if str(binary) != readiness.get('binary_path') or digest(binary) != readiness.get('binary_sha256'):
            ap.error('validated binary hash/path mismatch')

    pi = shutil.which('pi')
    if pi is None:
        ap.error('pi not found on PATH')
    help_result = subprocess.run([pi, '--help'], text=True,
                                 capture_output=True, timeout=30)
    for required in ('--model', '--thinking', '--mode', '--session-dir', '--no-skills',
                     '--no-extensions', '--no-context-files', '--no-prompt-templates', '--tools'):
        if required not in (help_result.stdout + help_result.stderr):
            ap.error(f'Pi CLI does not advertise {required}: inspect local version before run')
    pi_version = command(pi, '--version')

    out = basedir / 'runs' / a.run_id
    if out.exists():
        ap.error(f'output already exists: {out}. Never overwrite benchmark evidence')
    out.mkdir(parents=True)
    session_dir = out / 'sessions'
    session_dir.mkdir()
    prompt = prompt_path.read_text()
    (out / 'prompt.md').write_text(prompt)
    (out / 'pi-help.txt').write_text(help_result.stdout + help_result.stderr)

    # Running from identical parent cwd prevents repository-local Pi context differences.
    argv = [pi, '--mode', 'json', '--session-dir', str(session_dir),
            '--model', a.model, '--thinking', a.thinking,
            '--no-skills', '--no-context-files', '--no-prompt-templates',
            '--no-extensions', '--tools', 'read,bash']
    for ext in a.extension:
        argv.extend(['--extension', ext])
    argv.append(prompt)
    env = os.environ.copy()
    reporting_reserve = 60
    reporting_epoch = int(time.time() + a.seconds - reporting_reserve)
    deadline_epoch = reporting_epoch + reporting_reserve
    env.update({
        'BENCH_REPORTING_EPOCH': str(reporting_epoch),
        'BENCH_DEADLINE_EPOCH': str(deadline_epoch),
        'GOPROXY': 'off',
        'GOSUMDB': 'off',
        'GOFLAGS': '-mod=readonly',
        'GOTOOLCHAIN': 'local',
        'BENCH_ARTIFACT_DIR': str(out),
    })
    # Do not expose tool access to the control even via this environment variable.
    env.pop('REFFECTOR_BIN', None)
    if 'reffector' in a.case:
        env['REFFECTOR_BIN'] = str(binary)

    info = {
        'case': a.case, 'run_id': a.run_id,
        'repository': str(repo_dir), 'commit': EXPECTED[repo],
        'model_requested': a.model, 'thinking_requested': a.thinking,
        'pi_version': pi_version, 'pi_path': pi,
        'extensions_explicit': a.extension,
        'prompt_file': prompt_filename, 'prompt_sha256': digest(prompt_path),
        'budget_seconds': a.seconds, 'reporting_reserve_seconds': reporting_reserve,
        'reporting_epoch': reporting_epoch, 'deadline_epoch': deadline_epoch,
        'started_at_utc': now(),
        'argv_except_prompt': argv[:-1],
        'offline_env': {k: env[k] for k in ('GOPROXY', 'GOSUMDB', 'GOFLAGS', 'GOTOOLCHAIN')},
        'artifact_dir': str(out),
        'binary_sha256': digest(binary) if 'reffector' in a.case else None,
        'initial_status': status_before,
    }
    (out / 'run.json').write_text(json.dumps(info, indent=2) + '\n')
    start = time.monotonic()
    timed_out = False
    with (out / 'events.jsonl').open('wb') as stdout, (out / 'stderr.txt').open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=experimentdir, env=env,
                                   stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            exitcode = process.wait(timeout=a.seconds)
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                os.killpg(process.pid, signal.SIGINT)
            except ProcessLookupError:
                pass
            try:
                exitcode = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    exitcode = process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    exitcode = process.wait()
    info.update({
        'ended_at_utc': now(),
        'elapsed_wall_seconds': round(time.monotonic() - start, 3),
        'timed_out': timed_out,
        'ended_early': not timed_out and time.monotonic() - start < a.seconds - reporting_reserve,
        'process_exit_code': exitcode,
        'final_status': command('git', 'status', '--porcelain=v1', cwd=repo_dir),
    })
    info['repository_modified'] = info['final_status'] != status_before
    (out / 'run.json').write_text(json.dumps(info, indent=2) + '\n')
    print(f'RUN={out}\nEXIT={exitcode}\nTIMED_OUT={timed_out}\nREPOSITORY_MODIFIED={info["repository_modified"]}')
    if timed_out or exitcode != 0 or info['repository_modified']:
        return 2
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, OSError, ValueError) as ex:
        print(f'RUNNER ERROR: {ex}', file=sys.stderr)
        sys.exit(2)
