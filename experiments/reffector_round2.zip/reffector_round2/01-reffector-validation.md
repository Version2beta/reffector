# Prompt 1 — Reffector read-only acceptance audit

You are conducting a **read-only acceptance audit**, not implementing or repairing software. Inspect the *local* Reffector code, not GitHub main, and establish exactly what is implemented. Do not infer success from the previous assignments or assume that flags suggested in an earlier specification exist.

## Locations and fixed inputs

- Reffector source: `/Users/rob/Development/reffector`
- Caddy: `/Users/rob/Development/reffector/experiments/caddy`, required HEAD `0e392c89baa50f558bc24440482c5d57fff4499f`, intended scope `./modules/caddyhttp/...`
- restic: `/Users/rob/Development/reffector/experiments/restic`, required HEAD `dd09b6bd01af220b1d5d95c0d4d7d472e05e05c4`, intended scopes `./internal/repository/... ./internal/backend/local/...`
- Audit artifacts and built executable (outside all source repositories): `/Users/rob/Development/reffector-round2/audit/` and `/Users/rob/Development/reffector-round2/bin/reffector`

You may create or replace files *only in these audit and bin artifact directories*, including the compiled executable and sample reports. You may run `go` build/test/vet and allow their external caches to change. Do not modify, format, install into, commit, clean, or repair Reffector or either third-party repository. Do not run a fixer. Do not download dependencies or change Go module metadata. Treat any existing unrelated dirty files as user work; record them without changing them. If dependencies are absent, mark the affected test **blocked by environment**, not as an analyzer defect.

## Procedure

1. Record UTC start/end, host OS/architecture, `go version`, Reffector Git HEAD, `git status --porcelain=v1`, relevant diffs, Go version constraints, and any uncommitted changes. The working tree may contain the actual improvements. Inspect source, tests, README, man page and agent skill, but trust executable behavior over documentation when they disagree.
2. Discover the actual CLI from source and `-h`/`--help` as supported; do not assume flags such as `-all`, `-stats`, `-recursive`, or `-callers`. Build **this exact source** with `go build -o /Users/rob/Development/reffector-round2/bin/reffector ./cmd/reffector`. Record SHA-256 of the binary and help output. Never substitute `/Users/rob/go/bin/reffector` merely because it is installed. Record the binary's version if implemented; otherwise identify it by local Git HEAD, dirty-tree status, and SHA-256.
3. Run applicable `go test ./...`, `go vet ./...`, and `go build ./...` from the Reffector root. Report exit codes and failures. Any additional checks must be safe and read-only with respect to sources. If tests use generated fixtures, ensure test infrastructure confines modifications to scratch space.
4. Determine and **behaviorally test** the following, using fixtures plus focused real-code samples. For each item mark `PASS`, `PARTIAL`, `FAIL`, `NOT IMPLEMENTED`, or `BLOCKED`, with command, observed output, and evidence:
   - Recursively expanding a local-directory argument and explicitly selecting an exact package; independently compare the actual selected package list against `go list`.
   - Complete source-function inventory, including zero-effect and non-uncertain functions, and coverage statistics with a meaningful denominator; distinguish source functions from synthetic, test, dependency, and compiler-generated functions.
   - A direct effect site's exact resolved Go API (package-qualified identity), file, line/column, and stable identity; inherited effects must not masquerade as direct sites.
   - Principal **effect-centered** projection: effect category -> distinct direct application operation site -> reverse callers; function-oriented view as alternative if implemented.
   - Caller edges and their source provenance; reverse paths to useful entry points, configurable depth, cycle handling, and explicit boundary when a call is unresolved.
   - Sites that are truly independent remain distinct; many callers of a single implementation must not be counted as many sites. Exercise interface calls/callbacks and dynamic dispatch conservatively.
   - Uncertainty provenance/reasons; do not treat unresolved execution as absence of effects or fabricate a concrete target.
   - Filters/selective graph queries, stable ordering/IDs, deterministic repeated output, and bounded caller-graph output in cycles or large graphs.
   - New consequential operations (if present), particularly HTTP response output, resource lifecycle/cleanup, and error-sensitive boundaries. Missing new categories are limitations, not implied defects.
   - Regressions against old effect recognition or read-only behavior. Explicitly note what remains unmodeled (e.g. memory mutation, aliasing, resource ownership, synchronization).
5. Check the *exact pinned revisions and package sets* in Caddy and restic. From each repository, execute `go list -f '{{.ImportPath}}'` on the intended scope with `GOPROXY=off`, `GOSUMDB=off`, `GOFLAGS=-mod=readonly`, and the prepared local toolchain. Record package count, list, non-test Go source file count, and whether load errors occur. Use portable tools or Go itself to count; avoid quoting size estimates as measured data.
6. Run the freshly built Reffector binary against both intended scopes entirely offline. Capture stdout, stderr, exit status, runtime with an external monotonic clock, and bounded sample JSON/text outputs in the audit artifact directory. Check that operations in **subpackages**, including relevant Caddy reverse-proxy code, really appear; check repository-level versus `internal/backend/local` paths in restic. Check that output is suitable for selective investigations, rather than an enormous undifferentiated dump. Repeat a normalized deterministic query twice and compare exact bytes (if output contains unstable timestamps, report this separately).
7. Rerun `git status --porcelain=v1` on all three repositories and compare it with the initial snapshots. Distinguish changes caused by this audit from pre-existing user modifications. Do not repair anything.

## Benchmark readiness gate

Say **READY** only if all of these hold:
- Source is buildable and its applicable tests pass, or any skipped tests are isolated and demonstrably irrelevant to the required interface. No unexplained critical regression.
- The executable's SHA-256 is recorded and corresponds to this build, not an older installed copy.
- Both pinned repository scopes load completely offline, with no missing dependencies or type information.
- Correct recursive scope, complete function inventory, direct operation-site provenance, the effect-centered inverted query, distinct shared-vs-independent sites, useful reverse caller paths, uncertainty boundaries, and bounded deterministic output have **observed** evidence. Treat a missing core capability as NOT READY, not an invisible workaround.
- Output can be queried selectively within a five-minute benchmark investigation; package counts and size are explicitly accepted. If scope is too large for credible coverage, recommend a *single revised scope to be fixed identically for both agents before either benchmark run*; do not silently change it.
- Third-party worktrees remained unchanged by this audit.

Write:
1. `/Users/rob/Development/reffector-round2/audit/acceptance.md`: matrix of capabilities with evidence (commands, file:line in analyzer where relevant, sample output paths), regressions, performance, package counts, actual flags/subcommands, unknowns, and READY/NOT READY decision.
2. `/Users/rob/Development/reffector-round2/audit/readiness.json`: machine-readable summary with at least `ready` (boolean), `source_head`, `source_dirty` (boolean), `binary_path`, `binary_sha256`, `caddy_head`, `restic_head`, `caddy_scope` (string), `restic_scopes` (array), `caddy_packages` and `restic_packages` (arrays), `effect_query_example_caddy` and `effect_query_example_restic` (literal commands that succeeded), `unresolved_gaps` (array), and `tested_at_utc`.
3. A concise final response linking to those local artifact paths (plain paths), summarizing failures and showing the **verified literal CLI invocations** for Caddy/restic (no invented option names).

Do not benchmark or fix any code in this task. If the audit is NOT READY, stop there and explain exactly what must change before round two is meaningful.
