# Reffector round two — controlled acceptance audit and agent benchmark

**Status:** This is a ready-to-run *protocol*, not a claim that the local improved Reffector or the cached test repositories have passed validation. Nothing has been executed on `/Users/rob/Development/reffector` from this environment. The local audit is the gate.

## Deliverables

| File | Purpose |
| --- | --- |
| `01-reffector-validation.md` | Read-only local acceptance audit and actual CLI discovery |
| `02-caddy-control.md` | Caddy source-only investigation |
| `03-caddy-reffector.md` | Paired Caddy Reffector-assisted investigation |
| `04-restic-control.md` | restic source-only investigation |
| `05-restic-reffector.md` | Paired restic Reffector-assisted investigation |
| `run_round2.py` | Standard-library-only macOS-compatible Pi launcher with a 300-second hard process limit and independent sessions |
| `extract_metrics.py` | Extract actual persisted-session model, thinking-level, usage, costs and tools, without guessing source coverage |

## Scope lock

- Caddy: `0e392c89baa50f558bc24440482c5d57fff4499f`, `./modules/caddyhttp/...` (includes descendant packages and in-scope reverse proxy).
- restic: `dd09b6bd01af220b1d5d95c0d4d7d472e05e05c4`, `./internal/repository/... ./internal/backend/local/...`.
- Use the **same exact package list** in a control/treatment pair. Audit `go list` expansion and verify no unexpected package omissions. The scope must be fixed before either measured session; no unilateral post-hoc narrowing.

## Execution checklist

1. Place these files in `/Users/rob/Development/reffector-round2/` (create the directory, not inside the Reffector Git worktree). Ensure both third-party repositories are at the pinned HEADs; preserve any dirty user work and stop if their worktrees are not clean.
2. Run `01-reffector-validation.md` as a **separate unmeasured Pi session** from `/Users/rob/Development/reffector`. A candidate command (after `pi --help` verifies the flags and the physical model route) is:

   ```sh
   cd /Users/rob/Development/reffector
   mkdir -p /Users/rob/Development/reffector-round2/audit
   pi --mode json --no-skills --no-extensions --no-context-files --no-prompt-templates \
      --tools read,bash --model openai-codex/gpt-6.1-sol --thinking high \
      "$(cat /Users/rob/Development/reffector-round2/01-reffector-validation.md)" \
      > /Users/rob/Development/reffector-round2/audit/validation-events.jsonl
   ```

   If the pinned physical model requires a specific router extension, explicitly load that known extension rather than allowing a silent fallback. The validator can write **only** audit artifacts and build the audited binary in `/Users/rob/Development/reffector-round2/bin/`. It should produce `audit/acceptance.md` and `audit/readiness.json`. Do not let it repair code, modify repositories or invent CLI options. Validation stops on `ready=false`.
3. Inspect the audit's actual supported flags/query examples, source commit and dirty state, binary SHA-256, sample effect-centered report, actual package lists/counts/sizes, caller paths, uncertainty, and determinism. Verify source/test evidence rather than accepting a narrative declaration. If a core capability is missing, change Reffector **outside** the audit and repeat the audit from scratch; freeze the resulting binary before benchmarking.
4. **Separately warm dependency and Go build caches.** Online downloads, if needed, belong only to an approved preparation session; never allow network access inside the measured sessions. For both repositories preflight `GOPROXY=off GOSUMDB=off GOFLAGS=-mod=readonly GOTOOLCHAIN=local go list -deps <scope>`; optionally `go test -run '^$' <scope>` to compile; preserve working trees. Run the Reffector preflight on both scopes outside measurement. Incomplete type information or missing dependencies invalidate a run, not an analyzer failure. Record times and errors.
5. Confirm `pi --help` supports the launcher flags. Default launch is fixed model `openai-codex/gpt-6.1-sol`, reasoning `high`, with skills, context files, prompt templates and discovered extensions disabled. **Model router caveat:** if the chosen physical model is available only through an extension, include exactly the same explicitly pinned extension using `--extension /path` for *every* run; never quietly change the model. Compare the physical model and thinking level from the session records before accepting each pair. `--no-extensions` combined with an explicit `--extension` is supported in published Pi docs, but verify locally.
6. Launch each measured investigation once per Pi process; there is no session resume or inter-repository continuation. Examples from the protocol directory:

   ```sh
   python3 run_round2.py --case caddy-control   --run-id caddy-control-01
   python3 run_round2.py --case caddy-reffector --run-id caddy-reffector-01
   python3 run_round2.py --case restic-control  --run-id restic-control-01
   python3 run_round2.py --case restic-reffector --run-id restic-reffector-01
   ```

   The runner invokes `pi --mode json` with isolated `--session-dir`, `--tools read,bash` (no edit/write tool), and `--no-skills --no-context-files --no-prompt-templates --no-extensions`. It executes from the same `experiments/` directory, with a fresh Pi process for every case. It enforces **300 seconds externally** by signaling the Pi process group, with a few seconds of shutdown grace. It records actual wall time and an explicit timeout flag; a timed-out process is **censored**, not falsely scored as zero. The runner does not make the shell read-only; enforce source integrity with clean-worktree checks before and after and inspect command traces. If the runner reports a nonzero code or modification, investigate and invalidate as appropriate—never discard user changes.
7. Prefer at least **two independent repetitions per configuration/repository** (eight total benchmark sessions) using distinct run IDs. Pre-register order, e.g. Caddy: control/treatment then treatment/control; restic: treatment/control then control/treatment. Change order across pairs, not scopes or instruction wording; do not share session context. Report results per run and median/range (do not imply statistical significance from n=2). A single pair remains pilot data.
8. Extract Pi telemetry from the persisted session of each run and independently assess the findings. Re-run a changed experiment **only** after recording its failure/invalidity, with the reason and replacement run ID; never overwrite raw logs.

## Five-minute fixed-budget experiment

- **300 seconds total wall time per run**, beginning with Pi launch and including startup, all model and tool execution, Reffector queries, and the final report. The runner enforces the hard limit identically across all four cases. This is an **equal-time opportunity**, not an instruction to sit idle until the clock runs out.
- **Phase 1 (first ~45–60 seconds):** rapidly identify a ranked inventory of consequential operation groups and candidate architectural opportunities. Aim for ≥3 groups across ≥2 risk domains where present, but record actual coverage rather than manufacturing quotas.
- **Phase 2 (until ~minute four):** iteratively select the **highest expected engineering payoff per unit effort**, examine direct operation sites and controlling paths, test assumptions and counterevidence, classify or defer the lead, **rerank the queue**, and repeat. Favor supported architectural simplifications that remove independent correctness obligations, not raw candidate counts. A high-value deep finding beats several superficial claims.
- **Phase 3 (last ~60 seconds):** concise, source-backed final report: coverage and candidate ledgers, up to three best findings, unresolved areas, next highest-priority lead, and actual work accomplished. The runner supplies `BENCH_REPORTING_EPOCH` and `BENCH_DEADLINE_EPOCH` so agents can check `date +%s` and reserve the same reporting window.
- **Stopping:** do not stop because a specified number of groups or findings was reached. Stop early only for a genuinely exhausted useful queue or invalid prerequisites, with reasons. Never idle to fill the time. Record actual early exits and elapsed time; flag them when comparing equal-budget results. A time-capped run without a final report retains timestamped transcript evidence but its missing results must not be treated as zero findings.
- **Comparability:** constant wall-time limits do **not** guarantee equal model-token usage or dollar cost. Report those as outcomes. Any change to duration/reporting rules must be made for both arms before repeating the benchmark; do not adapt one side independently.

## Common metrics schema

Record one JSON-compatible row per run, with `null` for unavailable values (do not invent measurements):

```json
{
  "case": "caddy-control",
  "repeat": 1,
  "valid": true,
  "invalid_reason": null,
  "revision": "0e392c89baa50f558bc24440482c5d57fff4499f",
  "scope": ["./modules/caddyhttp/..."],
  "packages_selected": null,
  "go_source_files_in_scope": null,
  "reffector_source_sha": null,
  "reffector_binary_sha256": null,
  "physical_model": null,
  "thinking_level": null,
  "pi_version": null,
  "pi_extensions_context": null,
  "budget_seconds": 300,
  "elapsed_seconds": null,
  "timed_out": null,
  "ended_early": null,
  "reporting_reserve_seconds": 60,
  "stage1_finished_seconds": null,
  "time_to_first_verified_call_path_seconds": null,
  "tool_calls_to_first_verified_call_path": null,
  "input_tokens": null,
  "cached_input_tokens": null,
  "cache_write_tokens": null,
  "output_tokens": null,
  "total_model_tokens": null,
  "model_reported_cost_usd": null,
  "tool_calls": null,
  "source_search_commands": null,
  "distinct_source_files_read": null,
  "analyzer_runtime_seconds": null,
  "analyzer_query_count": null,
  "analyzer_sites_returned": null,
  "analyzer_uncertainties": null,
  "domains_surveyed": null,
  "operation_groups_surveyed": null,
  "distinct_operation_sites_examined": null,
  "candidate_count": null,
  "depth_investigations": null,
  "candidates_rejected": null,
  "candidates_unresolved": null,
  "findings_reported": null,
  "findings_validated": null,
  "high_value_findings": null,
  "unexplored_risk_domains": [],
  "coverage_ledger_path": null,
  "blind_evaluation_path": null
}
```

For the control, Reffector fields are **not applicable** (`null`), not `0` to imply the tool failed to produce effects. Analyzer coverage (sites correctly represented by the analyzer on the frozen scope) and agent coverage (sites actually investigated) must be compared against a separately audited reference inventory; neither is inferred from counts alone.

### Telemetry extraction

Run from the protocol directory (point the script to the exact run):

```sh
python3 extract_metrics.py /Users/rob/Development/reffector-round2/runs/caddy-control-01
```

The extractor reads **persisted Pi session JSONL**, not just agent self-report, and writes `metrics.json`. It records assistant messages' physical provider/model, any recorded thinking levels, Pi usage including cached input/output and costs, tool calls, plus exact run timestamps and process outcomes. It does not double-count streamed `message_update` deltas. If Pi's installed version omits `thinkingLevel` or other fields, mark `unrecorded` rather than assuming the requested flags were honored; inspect actual response metadata, extension router logs or pause the experiment. Confirm there is one fresh session file and no branching/compaction duplication before counting. `usage.totalTokens` must be interpreted according to actual Pi/provider definitions; report raw components alongside totals and never compute a silently incompatible sum.

For phase/reconstruction timing, compare `milestones.tsv` (if created) against actual timestamped Pi tool events in session JSONL. `first_call_path` is only an agent-declared candidate milestone; verify the cited trace, and count tool calls and consumed model usage before that exact event. An unresolved boundary must not be counted as a *verified complete* caller path.

For **source files read**, review `read` calls and `bash` tool commands *and their actual output*; a grep match list is not proof that the agent inspected each file. Distinguish search commands from files inspected, and report both. Correlate Reffector invocations with bash tool events and analyzer output paths; use monotonic command timers (`/usr/bin/time -p` or a Python monotonic wrapper, measuring only analyzer execution) and count actual successful queries. The extractor deliberately avoids pretending that filename heuristics can establish coverage or finding validity.

## Independent blind evaluation

1. Create **anonymized finding cards**, stripping which method found them, analyzer mentions, tool query IDs, original agent ranking, and candidate IDs. Keep only claim, affected source paths and lines, a minimal reproducible call/control trace, intended invariant, proposed change, risks, and proposed tests. Randomize order and avoid pairing obvious formatting clues; a separate organizer retains mappings.
2. Have a reviewer with **access to the pinned source** assess each finding without knowing arm or first-round findings. A second reviewer is preferable; resolve disagreements with a documented adjudication. Verify method/API identity, in-scope reachability, distinct vs shared sites, necessary preconditions, relevant existing tests, and plausible counterexamples. Explicitly distinguish `source-supported architectural opportunity`, `plausible but unresolved`, `reproduced defect`, and `unsupported/rejected`. Do not label a static hypothesis a confirmed defect.
3. Score dimensions **separately**, each 0–4 using a preregistered rubric:
   - **Validity:** 0 refuted, 1 weak/incorrect key link, 2 plausible but important unresolved assumptions, 3 well-supported from source, 4 independently reproduced or rigorously established.
   - **Architectural value:** 0 cosmetic/no net reduction, 1 small localized simplification, 2 useful reduction of one independent obligation, 3 meaningful consolidation/enforceable boundary across paths, 4 major reduction in high-impact independent obligations without transferring them elsewhere.
   - **Consequence:** 0 cosmetic, 1 minor operational nuisance, 2 recoverable disruption, 3 significant integrity/availability/trust failure potential, 4 severe data loss/security/system-wide failure risk with credible path.
   - **Actionability:** 0 not actionable, 1 vague, 2 direction possible but unvalidated, 3 concrete design and tests, 4 clear safe path with bounded risks and convincing tests.
   Report unresolved uncertainty and disagreement, not a single blended score. Reproducing a failure must be performed **in a safe disposable environment** after the benchmark, not in read-only measured sessions.
4. Independently construct/reference a **stratified inventory of important operational responsibilities** for each frozen scope using source inspection, not Reffector results alone. Include non-effect-model domains such as synchronization and observable mutable state. Use this to evaluate missed high-consequence areas and bias toward analyzer-visible effects. Do not reveal this inventory to agents in advance. Review first-round findings only **after** second-round submissions are frozen.
5. Compare per repository and repeat: depth/breadth completeness, correctly identified independent sites, unique validated architectural improvements, validity/engineering value, cost/tokens/wall time and false positives. Match duplicate findings by root cause across runs. Report treatment cases that underperform or miss important code. Do not select success metrics after looking at results.

## Interpretation and development decision

- **Analyzer coverage:** what Reffector represents correctly, not simply how many JSON records it emits.
- **Agent coverage:** which operation groups, distinct sites, and controlling paths the agent actually examined, including why it deferred/rejected others.
- **Finding validity:** independent reviewer assessment after challenging source assumptions.
- **Engineering value:** independently enforced checks, failure paths or ownership obligations that a safe change would eliminate, rather than a generic refactor count.
- **Efficiency:** tokens, time, monetary cost and load/query overhead reported separately; quality can improve even if speed worsens, and vice versa.

A useful result might show better breadth but not greater depth, or a larger candidate inventory without more valid findings. It might also show Reffector suppresses important investigation outside recognized effects. Both positive and negative outcomes should change what Reffector builds next. This design does **not** assert an improvement until the frozen, repeated experiments and blind assessment support it.

## External documentation used to design the launcher

- [Reffector public README](https://github.com/Version2beta/reffector) — currently documents the older direct/function effects and `-json` output; **not evidence that the local improved CLI exists**.
- [Pi CLI usage](https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/usage.md) — model, thinking, no-skills, extensions, session-dir flags (verify your installed Pi version).
- [Pi CLI integration](https://pi.dev/docs/latest/cli-integration) — `--mode json` event stream semantics.
- [Pi session format](https://github.com/earendil-works/pi/blob/main/packages/coding-agent/docs/session-format.md) — persisted JSONL messages, usage, actual provider/model, optional thinkingLevel.
