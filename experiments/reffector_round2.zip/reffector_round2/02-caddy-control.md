# Prompt 02 — Caddy — control

## Caddy-specific mission and priorities

Repository: `/Users/rob/Development/reffector/experiments/caddy`
Required HEAD: `0e392c89baa50f558bc24440482c5d57fff4499f`
**Exact selected scope** (recursive): `./modules/caddyhttp/...`

Prioritize HTTP response behavior/external output; request routing, handler and middleware boundaries; connection acquisition and cleanup; configuration and server lifecycle; concurrency and resource ownership; and trust or policy decisions that govern observable operations. Survey the core HTTP package **and** reverse-proxy code within selected subpackages. Pay attention to dynamic handler composition, interfaces, closures and callbacks: a shared implementing site with many callers is different from multiple independent sites that separately enforce a policy. An analyzer or grep hit does not establish an applicable security policy.

## Shared experimental contract

You are one independent Pi benchmark session. Your task is **investigative, not an implementation task**: identify places where consequential operations and their controlling paths create independent correctness, security, availability, or recovery obligations; determine whether consolidation or stronger boundaries could reduce those obligations. A true defect is valuable when supported, but do not hunt for a prescribed number of defects. Do not treat effect category, call frequency, or an unresolved edge as a vulnerability.

**Read-only:** Do not edit, format, generate files inside, commit, clean, or run mutating application commands in the repository. Do not make network calls. You may run read-only source queries, `go list`, inspect existing tests, and reason from source; do not run an end-to-end command that changes user/repository data. Go's already warmed external caches may be used. Any output artifacts belong only in `$BENCH_ARTIFACT_DIR` outside the source tree. The external launcher enforces a **300-second (five-minute) end-to-end wall-clock limit**, measured from Pi launch (including tool/model latency and report writing). Do not try to extend it. The launcher supplies `BENCH_REPORTING_EPOCH` (begin report by then) and `BENCH_DEADLINE_EPOCH` (hard stop), as Unix timestamps; check `date +%s` periodically to allocate time. All Go commands must remain offline (`GOPROXY=off`, `GOSUMDB=off`, `GOFLAGS=-mod=readonly` supplied by launcher). If pinned revision, scope, caches, model/tool environment, or read-only constraints fail, report `INVALID RUN` promptly rather than silently fixing them.

Confirm `git rev-parse HEAD` equals the required SHA. Work exclusively inside the **stated scope**, including its selected subpackages; inspect out-of-scope definitions only to resolve necessary call edges, explicitly marking them as context rather than additional surveyed scope. Start from `/Users/rob/Development/reffector/experiments`; change to the repository directory before using Go tools. Record the actual selected package list using `go list -f '{{.ImportPath}}'` and note loading errors. Do not use information, results, or hints from previous experimental sessions.

### Risk-based prioritization

Assess **consequence and obligation**, not raw counts. Prefer (1) externally visible integrity/confidentiality/availability consequences and trust or policy boundaries, (2) persistent or destructive changes and failure recovery, (3) resource lifetime/availability, (4) repeated independent implementations of the same operation or invariant, (5) concurrency/synchronization hazards, then lower-consequence maintenance operations. Adjust ordering from concrete source evidence, including failure severity, exposed callers, recovery possibility, and test coverage. Distinguish sites with several reverse callers from genuinely distinct direct sites.

### Stage 1: rapid breadth (~first 45–60 seconds)

Make an **initial ranked inventory**, not an exhaustive sweep. Quickly inspect materially different consequential responsibilities in the selected scope; aim to identify at least **three distinct operation groups across two or more risk domains**, if evidence permits. Consider every repository-specific priority when deciding what to investigate; do not spend the whole budget checking each domain exhaustively. An operation group is a meaningful responsibility with representative direct operation site(s), not a file name or the number of callers. For each group record a brief `G#`, domain, intended guarantee, source `path:line`, possible consequence, independent/shared/unknown status, and tentative priority. State when an important domain has not been surveyed. Inadequate evidence is grounds to mark unknown, not to invent a group or claim.

Select the strongest opportunity based on **likely engineering payoff per unit investigative effort**: consequence, independent correctness obligations potentially removable, strength of supporting evidence, and cost of resolving uncertainty. The survey is a starting point; update the inventory and priorities during depth work.

### Stage 2: iterative, prioritized depth (until the reporting window)

**Repeat:** choose the current highest-payoff unexplored candidate; examine its direct operation sites, calling/control paths, intended invariant, trust decisions (if any), failure/recovery, resource lifetime, concurrency, and existing tests where relevant; actively seek a disconfirming explanation; classify as supported opportunity, unresolved hypothesis, rejected, or deferred; then **reprioritize** the remaining candidates and repeat. Distinguish one shared enforcing implementation with many callers from genuinely independent operation sites. Consider whether an architectural change could *remove* an independent obligation instead of moving it. Do not spend disproportionate time on a low-payoff or unresolvable lead: capture what is unknown, defer it, and move to the next. If an initial lead proves promising, continue to test its assumptions rather than prematurely declaring a defect.

There is **no fixed quota of investigated candidates or positive findings**. One deeply supported opportunity may be worth more than three speculative ones. Continue investigating valuable opportunities until `BENCH_REPORTING_EPOCH`; do not conclude merely because an initial breadth target or three findings have been reached.

### Comparable progress markers

When Stage 1 breadth is complete, run `printf 'stage1_complete\t%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$BENCH_ARTIFACT_DIR/milestones.tsv"`. When you first verify a *complete, source-backed* direct-operation-to-controlling-caller path, run `printf 'first_call_path\t%s\t%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" 'path:line' >> "$BENCH_ARTIFACT_DIR/milestones.tsv"`, replacing `path:line` with the proven direct site. Do not count an unresolved boundary as a complete trace; report it in the candidate ledger. Emit each marker once; never backdate or fabricate one. These are agent-declared milestones independently timestamped in Pi tool telemetry, not proof of validity. Use the same method regardless of investigation aid.

### Fixed-time stopping and reporting rule

Use the full **five-minute opportunity**, not a completion checklist: after each lead, identify and investigate the next highest-payoff one until the reporting window. Do not deliberately idle or perform low-value actions solely to consume time. Stop sooner only for an invalid environment or if a good-faith search identifies no further worthwhile leads; document why. Check the time using `date +%s` against `BENCH_REPORTING_EPOCH`. **Begin final reporting no later than the reporting epoch** (approximately minute four; the last ~60 seconds are reserved for a complete, compact report). A partial but source-supported report is preferable to a lengthy answer cut off by the external hard stop. All four configurations have the same limit and reporting reservation; startup, tool execution, Reffector overhead, and response writing count. The runner—not this prompt—measures actual duration, tokens and cost.

If a hard stop interrupts the report, the transcript and partial work remain evidence, but no completed-report finding count can be imputed. Do not use an external tool or additional session to finish after the deadline.

### Mandatory final report (Markdown, within this response)

1. `Run`: repository SHA, literal package scopes, `go list` package count, read-only/offline checks, investigation start/end timestamps from system clock if observed, and `completed / budget-limited / invalid` status. Do not claim a measured duration from an estimate; external runner measures elapsed time.
2. `Method`: ordinary navigation or Reffector-assisted and the exact commands used to establish coverage. Explain methodological limitations without changing the objective.
3. `Coverage ledger`: table with all `G#`, domain, responsibility, evidence site(s), shared/independent/unknown, risk rank, and disposition (`surveyed`, `deep`, `deferred`, `no-applicable-operation`). Explicitly identify unexplored/high-risk domains. This is an **agent coverage** report, not a percentage claimed about all possible source behavior.
4. `Candidate ledger`: all shortlisted, inspected, rejected, unresolved, and deferred hypotheses. For each record status and reason; distinguish recognized effects from actual evidence of correctness obligations.
5. `Top findings`: **up to three**, ordered by engineering value; for each supply an actionable title, source-backed facts with path:line, control/caller relationships and uncertainty, invariant and failure scenario, reasons for/against, proposed architectural change, independent correctness obligations removed (or state none), possible regression/verification tests, and remaining uncertainty. Classify `confirmed by source`, `plausible hypothesis`, or `rejected` accurately. A hypothesis is never called a reproduced defect unless reproduced.
6. `Investigation accounting`: group count, distinct direct site count **actually examined** (not estimated whole-program count), candidates considered/deep/rejected/unresolved, files genuinely read, source-search commands actually used (counts if possible), and important unresolved dispatch/callback/memory/concurrency boundaries. Do not fabricate counts. External telemetry, not your estimates, determines wall time/tokens/cost/tool calls.
7. `Next exploration`: highest-value area not fully inspected and why it remained (time, uncertainty, lower priority, or exhaustion); state whether you stopped early.

Limit the final report to source-backed observations. If no sound opportunities are found, say so; the coverage and rejection ledgers remain valuable.

## Control-only evidence method

You have **no access to Reffector** for this task. Do not invoke it, read its source, sample reports, output, tests, skills, preflight/audit results, or scripts. Do not invoke a substitute specialized side-effect/effect-graph analyzer. Use ordinary source navigation and standard Go tooling only, such as `rg`, `grep`, `find`, `sed`, reading source/tests, `go list`, and hand-built caller relationships based on source evidence. Do not assume grep identifies semantic Go API targets or dynamic call edges. Build the operation inventory independently, trace implementation sites and control paths, and explicitly record what ordinary investigation could not resolve within the budget. Do not search for earlier benchmark findings or read artifacts of other sessions.
