#!/usr/bin/env python3
"""Conservatively extract Pi persisted-session telemetry for one run.

Output is an evidence-based partial metrics record; fields unavailable in the
session format remain null or omitted. Never infer finding quality from logs.
"""
from __future__ import annotations
import argparse
import datetime as dt
from collections import Counter
import json
from pathlib import Path
import re
import sys


def load_rows(file: Path) -> list[dict]:
    rows = []
    for line in file.read_text(errors='replace').splitlines():
        try:
            ob = json.loads(line)
        except ValueError:
            continue
        if isinstance(ob, dict):
            rows.append(ob)
    return rows


def usage_rollup(messages: list[dict]) -> dict:
    fields = ['input', 'output', 'cacheRead', 'cacheWrite', 'totalTokens']
    sums = {key: 0 for key in fields}
    cost = 0.0
    counted = 0
    missing_total = 0
    for msg in messages:
        u = msg.get('usage') or {}
        if not isinstance(u, dict):
            continue
        counted += 1
        for k in fields:
            val = u.get(k)
            if isinstance(val, (int, float)):
                sums[k] += val
        if not isinstance(u.get('totalTokens'), (int, float)):
            missing_total += 1
        c = u.get('cost') or {}
        if isinstance(c, dict) and isinstance(c.get('total'), (int, float)):
            cost += c['total']
    return {
        'usage_records': counted, 'raw_reported': sums,
        'total_tokens_reliable': missing_total == 0 if counted else False,
        'model_reported_cost_usd': round(cost, 6),
        'cost_available': any(isinstance((m.get('usage') or {}).get('cost'), dict) for m in messages),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('run', type=Path, help='runs/<case-ID> directory created by run_round2.py')
    a = ap.parse_args()
    run = a.run.resolve()
    meta = json.loads((run / 'run.json').read_text())
    session_files = list((run / 'sessions').rglob('*.jsonl'))
    if len(session_files) != 1:
        print(f'ERROR: expected one persisted session, got {len(session_files)}; inspect manually: {session_files}', file=sys.stderr)
        return 2
    file = session_files[0]
    rows = load_rows(file)
    assistants = [r['message'] for r in rows if r.get('type') == 'message' and
                  isinstance(r.get('message'), dict) and r['message'].get('role') == 'assistant']
    extra_usage = [r for r in rows if r.get('type') == 'usage' and isinstance(r.get('usage'), dict)]
    other_usage = [r for r in rows if r.get('type') in ('compaction', 'branch_summary') and isinstance(r.get('usage'), dict)]
    usage_messages = assistants + extra_usage + other_usage
    model_counts = Counter(f"{m.get('provider', '?')}/{m.get('model', '?')}" for m in assistants)
    # Physical model, not selected router alias.
    thinking = Counter(m.get('thinkingLevel', 'unrecorded') for m in assistants)
    names = Counter()
    cmds = []
    for m in assistants:
        content = m.get('content') or []
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict) or block.get('type') not in ('toolCall', 'tool_call'):
                continue
            name = block.get('name', '?')
            names[name] += 1
            args = block.get('arguments') or {}
            if name == 'bash' and isinstance(args, dict):
                val = args.get('command') or args.get('cmd')
                if isinstance(val, str):
                    cmds.append(val)
    candidate_source_commands = [c for c in cmds if re.search(r'(^|[\s;|&])(rg|grep|find|sed|cat|git\s+grep|go\s+list)(\s|$)', c)]
    milestone_events = []
    for line in ((run / 'milestones.tsv').read_text().splitlines()
                 if (run / 'milestones.tsv').exists() else []):
        cols = line.split('\t')
        if len(cols) >= 2:
            milestone_events.append({'name': cols[0], 'utc': cols[1],
                                     'evidence_site': cols[2] if len(cols) > 2 else None})

    def seconds_since_start(label: str):
        times = [m['utc'] for m in milestone_events if m['name'] == label]
        if len(times) != 1:
            return None
        try:
            stamp = dt.datetime.fromisoformat(times[0].replace('Z', '+00:00'))
            origin = dt.datetime.fromisoformat(meta['started_at_utc'].replace('Z', '+00:00'))
            return round((stamp - origin).total_seconds(), 3)
        except (ValueError, KeyError):
            return None

    result = {
        'case': meta['case'], 'run_id': meta['run_id'],
        'session_file': str(file),
        'physical_models': dict(model_counts),
        'assistant_message_thinking_levels': dict(thinking),
        'requested_model': meta['model_requested'],
        'requested_thinking': meta['thinking_requested'],
        'session_row_count': len(rows),
        'milestones': milestone_events,
        'stage1_finished_seconds': seconds_since_start('stage1_complete'),
        'time_to_first_verified_call_path_seconds': seconds_since_start('first_call_path'),
        'tool_calls_total': sum(names.values()),
        'tool_calls_by_name': dict(names),
        'candidate_source_search_command_count': len(candidate_source_commands),
        'source_commands_unvalidated': candidate_source_commands,
        'wall_seconds': meta['elapsed_wall_seconds'],
        'timed_out': meta['timed_out'],
        'ended_early': meta.get('ended_early'),
        'budget_seconds': meta.get('budget_seconds'),
        'reporting_reserve_seconds': meta.get('reporting_reserve_seconds'),
        'process_exit_code': meta['process_exit_code'],
        'repository_modified': meta['repository_modified'],
        'usage': usage_rollup(usage_messages),
        'warnings': [
            'A command can inspect multiple files; source-search counts and distinct files require checking bash output/logs.',
            'Check physically recorded model ID and thinking level; requested flags alone do not establish them.',
            'Model token definitions and billing are provider-dependent; cached tokens are shown separately.',
            'A missing final report may mean externally censored investigation, not zero findings.',
        ],
    }
    target = run / 'metrics.json'
    target.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    print(f'Saved {target}')
    print(json.dumps({k: result[k] for k in ('physical_models', 'assistant_message_thinking_levels',
                                            'tool_calls_total', 'wall_seconds', 'usage')}, indent=2))
    return 0

if __name__ == '__main__':
    sys.exit(main())
